import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/doctor_model.dart';

class DoctorService {
  static const String _baseUrl =
      'https://medicalbd-001-site1.etempurl.com';

  static Future<List<Doctor>> getDoctors({
    int currentPage = 1,
    int itemsPerPage = 10,
  }) async {
    final Uri url = Uri.parse(
      '$_baseUrl/api/Doctors/GetAllDoctors'
          '?currentPage=$currentPage'
          '&itemsPerPage=$itemsPerPage',
    );

    final response = await http.get(
      url,
      headers: {
        'Accept': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final dynamic decodedData = jsonDecode(response.body);

      if (decodedData is List) {
        return decodedData
            .map(
              (json) => Doctor.fromJson(
            json as Map<String, dynamic>,
          ),
        )
            .toList();
      }

      throw Exception('Invalid API response format');
    }

    throw Exception(
      'Failed to load doctors. Status: ${response.statusCode}',
    );
  }

  static String? getDoctorImageUrl(String? image) {
    if (image == null || image.trim().isEmpty) {
      return null;
    }

    // If API later returns a complete image URL.
    if (image.startsWith('http://') ||
        image.startsWith('https://')) {
      return image;
    }

    // IMPORTANT:
    // Exact image base path was not included in the API response.
    // Change this after confirming the server's image directory.
    return '$_baseUrl/$image';
  }
}