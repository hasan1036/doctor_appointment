import 'package:flutter/material.dart';

import '../models/doctor_model.dart';
import '../services/doctor_service.dart';
import 'health_page_widgets.dart';

class DoctorsPage extends StatefulWidget {
  const DoctorsPage({super.key});

  @override
  State<DoctorsPage> createState() => _DoctorsPageState();
}

class _DoctorsPageState extends State<DoctorsPage> {
  final TextEditingController _searchController =
  TextEditingController();

  List<Doctor> doctors = [];

  bool isLoading = true;

  String? errorMessage;

  String selectedDepartment = 'All';

  @override
  void initState() {
    super.initState();

    _loadDoctors();
  }

  Future<void> _loadDoctors() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final result = await DoctorService.getDoctors(
        currentPage: 1,
        itemsPerPage: 10,
      );

      if (!mounted) return;

      setState(() {
        doctors = result;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        errorMessage = e.toString();
      });
    }
  }

  List<String> get departments {
    final departmentSet = doctors
        .map((doctor) => doctor.departmentName.trim())
        .where((name) => name.isNotEmpty)
        .toSet()
        .toList();

    departmentSet.sort();

    return departmentSet;
  }

  List<Doctor> get filteredDoctors {
    final query =
    _searchController.text.trim().toLowerCase();

    return doctors.where((doctor) {
      final bool matchesDepartment =
          selectedDepartment == 'All' ||
              doctor.departmentName == selectedDepartment;

      final bool matchesSearch =
          query.isEmpty ||
              doctor.name.toLowerCase().contains(query) ||
              doctor.specialization.toLowerCase().contains(query) ||
              doctor.qualification.toLowerCase().contains(query) ||
              doctor.departmentName.toLowerCase().contains(query) ||
              (doctor.hospital ?? '')
                  .toLowerCase()
                  .contains(query);

      return matchesDepartment && matchesSearch;
    }).toList();
  }

  IconData _getDepartmentIcon(String department) {
    final name = department.toLowerCase();

    if (name.contains('cardio') ||
        name.contains('heart')) {
      return Icons.favorite_rounded;
    }

    if (name.contains('neuro') ||
        name.contains('brain')) {
      return Icons.psychology_rounded;
    }

    if (name.contains('pulmo') ||
        name.contains('chest')) {
      return Icons.air_rounded;
    }

    if (name.contains('dental') ||
        name.contains('dentist')) {
      return Icons.medical_services_outlined;
    }

    if (name.contains('eye') ||
        name.contains('ophthalm')) {
      return Icons.visibility_outlined;
    }

    if (name.contains('medicine')) {
      return Icons.medication_outlined;
    }

    return Icons.local_hospital_outlined;
  }

  @override
  void dispose() {
    _searchController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return HealthPageScaffold(
      title: 'Doctors',
      subtitle: 'Your care and appointments',
      children: [
        const SizedBox(height: 18),

        // SEARCH BAR
        TextField(
          controller: _searchController,
          onChanged: (_) {
            setState(() {});
          },
          decoration: InputDecoration(
            hintText: 'Search doctors...',
            prefixIcon: const Icon(
              Icons.search_rounded,
            ),
            suffixIcon:
            _searchController.text.isNotEmpty
                ? IconButton(
              onPressed: () {
                _searchController.clear();

                setState(() {});
              },
              icon: const Icon(
                Icons.close_rounded,
              ),
            )
                : null,
            filled: true,
            fillColor: Colors.white,
            contentPadding:
            const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 14,
            ),
            border: OutlineInputBorder(
              borderRadius:
              BorderRadius.circular(14),
              borderSide: BorderSide(
                color: Colors.blueGrey.shade100,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius:
              BorderRadius.circular(14),
              borderSide: BorderSide(
                color: Colors.blueGrey.shade100,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius:
              BorderRadius.circular(14),
              borderSide: BorderSide(
                color: Colors.blue.shade300,
                width: 1.5,
              ),
            ),
          ),
        ),

        const SizedBox(height: 22),

        if (isLoading)
          const Padding(
            padding: EdgeInsets.symmetric(
              vertical: 60,
            ),
            child: Center(
              child: CircularProgressIndicator(),
            ),
          )
        else if (errorMessage != null)
          _buildError()
        else ...[
            _buildDepartments(),

            const SizedBox(height: 20),

            _buildDoctorTitle(),

            const SizedBox(height: 12),

            if (filteredDoctors.isEmpty)
              _buildEmpty()
            else
              ...filteredDoctors.map(
                    (doctor) => _DoctorCard(
                  doctor: doctor,
                  departmentIcon:
                  _getDepartmentIcon(
                    doctor.departmentName,
                  ),
                ),
              ),
          ],

        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildDepartments() {
    if (departments.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment:
      CrossAxisAlignment.start,
      children: [
        const Text(
          'Explore Medical Departments',
          style: TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Color(0xFF17202A),
          ),
        ),

        const SizedBox(height: 12),

        SizedBox(
          height: 120,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: departments.length,
            separatorBuilder:
                (context, index) =>
            const SizedBox(width: 10),
            itemBuilder: (context, index) {
              final department =
              departments[index];

              final selected =
                  selectedDepartment ==
                      department;

              return GestureDetector(
                onTap: () {
                  setState(() {
                    if (selected) {
                      selectedDepartment = 'All';
                    } else {
                      selectedDepartment =
                          department;
                    }
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(
                    milliseconds: 200,
                  ),
                  width: 105,
                  padding:
                  const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: selected
                        ? Colors.blue.shade50
                        : Colors.white,
                    borderRadius:
                    BorderRadius.circular(14),
                    border: Border.all(
                      color: selected
                          ? Colors.blue.shade400
                          : Colors
                          .blueGrey.shade200,
                      width:
                      selected ? 1.7 : 1.2,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment:
                    MainAxisAlignment.center,
                    children: [
                      Icon(
                        _getDepartmentIcon(
                          department,
                        ),
                        size: 38,
                        color: selected
                            ? Colors.blue.shade600
                            : Colors
                            .blueGrey.shade500,
                      ),

                      const SizedBox(height: 8),

                      Text(
                        '$department\nDepartment',
                        textAlign:
                        TextAlign.center,
                        maxLines: 2,
                        overflow:
                        TextOverflow.ellipsis,
                        style:
                        const TextStyle(
                          fontSize: 11,
                          height: 1.1,
                          fontWeight:
                          FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDoctorTitle() {
    return Row(
      children: [
        Expanded(
          child: Text(
            selectedDepartment == 'All'
                ? 'All Doctors List'
                : '$selectedDepartment Doctors',
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: Color(0xFF17202A),
            ),
          ),
        ),

        Text(
          '${filteredDoctors.length} doctors',
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade600,
          ),
        ),
      ],
    );
  }

  Widget _buildError() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 40,
      ),
      child: Center(
        child: Column(
          children: [
            Icon(
              Icons.cloud_off_rounded,
              size: 45,
              color: Colors.grey.shade500,
            ),

            const SizedBox(height: 12),

            const Text(
              'Unable to load doctors',
              style: TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 12),

            ElevatedButton(
              onPressed: _loadDoctors,
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmpty() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 40,
      ),
      child: Center(
        child: Column(
          children: [
            Icon(
              Icons.search_off_rounded,
              size: 45,
              color: Colors.grey.shade400,
            ),

            const SizedBox(height: 10),

            Text(
              'No doctors found',
              style: TextStyle(
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DoctorCard extends StatelessWidget {
  final Doctor doctor;

  final IconData departmentIcon;

  const _DoctorCard({
    required this.doctor,
    required this.departmentIcon,
  });

  @override
  Widget build(BuildContext context) {
    final String? imageUrl =
    DoctorService.getDoctorImageUrl(
      doctor.image,
    );

    return Container(
      margin: const EdgeInsets.only(
        bottom: 12,
      ),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
        BorderRadius.circular(15),
        border: Border.all(
          color: Colors.blueGrey.shade50,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(
              alpha: 0.06,
            ),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          _DoctorImage(
            imageUrl: imageUrl,
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        doctor.name,
                        maxLines: 2,
                        overflow:
                        TextOverflow.ellipsis,
                        style:
                        const TextStyle(
                          fontSize: 15,
                          fontWeight:
                          FontWeight.w700,
                          color:
                          Color(0xFF17202A),
                        ),
                      ),
                    ),

                    const SizedBox(width: 5),

                    Icon(
                      departmentIcon,
                      size: 21,
                      color: Colors
                          .blueGrey.shade400,
                    ),
                  ],
                ),

                const SizedBox(height: 4),

                Text(
                  doctor.specialization,
                  maxLines: 2,
                  overflow:
                  TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight:
                    FontWeight.w500,
                  ),
                ),

                const SizedBox(height: 5),

                Text(
                  doctor.qualification,
                  maxLines: 2,
                  overflow:
                  TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11,
                    color:
                    Colors.grey.shade600,
                  ),
                ),

                if (doctor.hospital != null &&
                    doctor.hospital!
                        .trim()
                        .isNotEmpty) ...[
                  const SizedBox(height: 7),

                  Row(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons
                            .local_hospital_outlined,
                        size: 14,
                        color: Colors
                            .blueGrey.shade500,
                      ),

                      const SizedBox(width: 4),

                      Expanded(
                        child: Text(
                          doctor.hospital!,
                          maxLines: 2,
                          overflow:
                          TextOverflow
                              .ellipsis,
                          style: TextStyle(
                            fontSize: 10.5,
                            color: Colors
                                .grey.shade700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],

                const SizedBox(height: 10),

                Align(
                  alignment:
                  Alignment.centerRight,
                  child: SizedBox(
                    height: 36,
                    child: ElevatedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(
                          context,
                        ).showSnackBar(
                          SnackBar(
                            content: Text(
                              doctor.name,
                            ),
                          ),
                        );
                      },
                      style:
                      ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor:
                        Colors.blue.shade100,
                        foregroundColor:
                        Colors.blue.shade900,
                        padding:
                        const EdgeInsets
                            .symmetric(
                          horizontal: 14,
                        ),
                        shape:
                        RoundedRectangleBorder(
                          borderRadius:
                          BorderRadius
                              .circular(9),
                        ),
                      ),
                      child: const Text(
                        'View Details',
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight:
                          FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DoctorImage extends StatelessWidget {
  final String? imageUrl;

  const _DoctorImage({
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    if (imageUrl == null) {
      return _placeholder();
    }

    return ClipOval(
      child: Image.network(
        imageUrl!,
        width: 72,
        height: 72,
        fit: BoxFit.cover,
        errorBuilder: (
            context,
            error,
            stackTrace,
            ) {
          return _placeholder();
        },
      ),
    );
  }

  Widget _placeholder() {
    return Container(
      width: 72,
      height: 72,
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        shape: BoxShape.circle,
      ),
      child: Icon(
        Icons.person_rounded,
        size: 45,
        color: Colors.blueGrey.shade300,
      ),
    );
  }
}